let links= ["https://www.youtube.com/watch?v=OCSbzArwB10", "https://www.youtube.com/watch?v=P4fCFom_KzI", "https://www.youtube.com/watch?v=8zKpP2tFLac", "https://www.youtube.com/watch?v=mGuYHXfgDxY", "https://www.youtube.com/watch?v=65VWIFlc4C4", "https://www.youtube.com/watch?v=i_DTzmk5JVM"]


function play1(){
    window.open(links[0]);
}


function play2(){
    window.open(links[1]);
}


function play3(){
    window.open(links[2]);
}


function play4(){
    window.open(links[3]);
}


function play5(){
    window.open(links[4]);
}


function play6(){
    window.open(links[5]);
}
